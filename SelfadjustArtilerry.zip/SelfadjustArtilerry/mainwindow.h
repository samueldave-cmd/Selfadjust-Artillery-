#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "Callout.h"
#include "View.h"
#include <QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QTimer>
#include <QtCharts/QValueAxis>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void calculation();
    void getInput();
    void accuracy1();
    void accuracy2();
    void calculation1();
    void chartcalculation();

private slots:
    void on_pushButton_pressed();

    void on_pushButton_2_pressed();

private:
    Ui::MainWindow *ui;
    int xcoordinate;
    int ycoordinate;
    int zcoordinate;
    int shell_105mm_velociy = 472;
    double radius;
    double gravitational = 9.810665;
    double radius2;
    double radius3;
    double predictiontime1;
    double predictiontime2;
    double Vzdegree1;
    double Vzdegree2;
    double refrence1;
    double refrence2;
    double Degreesin1;
    double Degreesin2;
    double Degreecos1;
    double Degreecos2;
    double AngleA;
    double AngleB;
    double accuracyA;
    double accuracyB;
    double Time;
    double targetprediction;


    QTimer *timer;
    QValueAxis *axisX;
    QValueAxis *axisY;

    QLineSeries *series;
    QChart *chart;
    QChartView *chartView;



    //Unused variable
    double height1;
    double xydegree;
    double Vxydegree;

    double caldegreesin1;
    double caldegreesin2;
    double caldegreecos1;
    double caldegreecos2;



};
#endif // MAINWINDOW_H
