#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cmath>
#include <QtMath>
#include <QDebug>
#include <QWidget>
#include "Callout.h"
#include "View.h"
#include <QVBoxLayout>
#include <QGraphicsLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}
//Total code is 340 from line 19 until 428
MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::getInput(){
    //get input from spinbox
    xcoordinate = ui->spinBox->value();
    ycoordinate = ui->spinBox_2->value();
    zcoordinate = ui->spinBox_3->value();
}

void MainWindow::calculation1(){
    //recheck the input
    if (xcoordinate == 0 && ycoordinate == 0 ){
        ui->textBrowser->append("Please put x or y value to define your target");
        ui->textBrowser_2->append("Please put x or y value to define your target");
        ui->textBrowser_3->append("Please put x or y value to define your target");
        ui->textBrowser_4->append("Please put x or y value to define your target");
        ui->textBrowser_5->append("Please put x or y value to define your target");
        ui->textBrowser_6->append("Please put x or y value to define your target");
        ui->textBrowser_8->append("Please put x or y value to define your target");
    }

    else {
        //calculate the target's distance
        radius = qSqrt(pow(xcoordinate, 2) + pow(ycoordinate, 2));

        double a = qAsin(ycoordinate/radius); //calculate the angle from 0,0 to target position
        double valuedegree = qRadiansToDegrees(a);

        double A = gravitational*radius*radius/(2*shell_105mm_velociy*shell_105mm_velociy);
        double B = -radius;
        double C =  A;
        double Discriminant = B*B - 4*A*C; //Component for calculate discriminant
        if (Discriminant < 0){ // recheck the discriminant
            ui->textBrowser->append("Target is out of reach");
            ui->textBrowser_2->append("Target is out of reach");
            ui->textBrowser_3->append("Target is out of reach");
            ui->textBrowser_4->append("Target is out of reach");
            ui->textBrowser_5->append("Target is out of reach");
            ui->textBrowser_6->append("Target is out of reach");
            ui->textBrowser_8->append("Target is out of reach");
        }

        else {
            double vv = qSqrt(Discriminant);

            double AA1 = (-B + vv);
            double AA2 = (-B - vv);

            double CC1 = 2*A;

            double AA11 = AA1/CC1;
            double AA22 = AA2/CC1; //Use quadratic formula to calculate the angle

            double AA111 = qAtan(AA11);
            double AA222 = qAtan(AA22); //set radian to tan value

            Vzdegree1 = qRadiansToDegrees(AA111); //convert it to angle value
            Vzdegree2 = qRadiansToDegrees(AA222);

            double ADegreesin1 = qSin(qDegreesToRadians(Vzdegree1)); //convert it to sin value
            double ADegreesin2 = qSin(qDegreesToRadians(Vzdegree2));

            double ADegreecos1 = qCos(qDegreesToRadians(Vzdegree1));//convert it to cos value
            double ADegreecos2 = qCos(qDegreesToRadians(Vzdegree2));

            double Vx11 = shell_105mm_velociy*ADegreecos1; //calculate the velocity
            double Vx21 = shell_105mm_velociy*ADegreecos2;

            double Vz11 = shell_105mm_velociy*ADegreesin1;
            double Vz21 = shell_105mm_velociy*ADegreesin2;

        if ((Vzdegree1 > 75 || Vzdegree1 < 0) && (Vzdegree2 < 0 || Vzdegree2 > 75)){
            ui->textBrowser->append("You've reached more than max angle");
            ui->textBrowser_2->append("You've reached more than max angle");
            ui->textBrowser_3->append("You've reached more than max angle");
            ui->textBrowser_4->append("You've reached more than max angle");
            ui->textBrowser_5->append("You've reached more than max angle");
            ui->textBrowser_6->append("You've reached more than max angle");
        } //make condition for the other calculations

        else{
            if (zcoordinate == 0) { //condition if the howitzer parallel to target

                double heightprojectory1 = pow(Vz11,2)/(2*gravitational); //height max formula
                double heightprojectory2 = pow(Vz21,2)/(2*gravitational);

                predictiontime1 = 2*Vz11/gravitational; //calculate time hit
                predictiontime2 = 2*Vz21/gravitational;

                radius2 = Vx11*predictiontime1; //calculate hit prediciton
                radius3 = Vx21*predictiontime2;

                ui->textBrowser_2->setText("2 time prediciton:"); //from 116 to 191 is to set the angle limit
                if ((Vzdegree2 > 75 || Vzdegree2 < 0) && (Vzdegree1 > 0 || Vzdegree1 < 75)){
                    ui->textBrowser_2->append(QString::number(predictiontime1));
                    ui->textBrowser_2->append("Barrel max 75");
                }
                else if ((Vzdegree1 > 75 || Vzdegree1 < 0)&& (Vzdegree2 > 0 || Vzdegree2 < 75)){
                    ui->textBrowser_2->append("Barrel max 75");
                    ui->textBrowser_2->append(QString::number(predictiontime2));
                }
                else{
                    ui->textBrowser_2->append(QString::number(predictiontime1));
                    ui->textBrowser_2->append(QString::number(predictiontime2));
                }

                ui->textBrowser->setText(" 2 recommended degree (Max 75):");
                if ((Vzdegree2 > 75 || Vzdegree2 < 0) && (Vzdegree1 > 0 || Vzdegree1 < 75)){
                    ui->textBrowser->append(QString::number(Vzdegree1));
                    ui->textBrowser->append("Barrel max 75");
                }
                else if ((Vzdegree1 > 75 || Vzdegree1 < 0)&& (Vzdegree2 > 0 || Vzdegree2 < 75)){
                    ui->textBrowser->append("Barrel max 75");
                    ui->textBrowser->append(QString::number(Vzdegree2));
                }
                else {
                    ui->textBrowser->append(QString::number(Vzdegree1));
                    ui->textBrowser->append(QString::number(Vzdegree2));

                }

                ui->textBrowser_3->setText("Distance between target and howitzer:");
                ui->textBrowser_3->append(QString::number(radius));

                ui->textBrowser_4->setText("2 Maximum height of projectile:");
                if((Vzdegree2 > 75 || Vzdegree2 < 0) && (Vzdegree1 > 0 || Vzdegree1 < 75)){
                    ui->textBrowser_4->append(QString::number(heightprojectory1));
                    ui->textBrowser_4->append("Barrel max 75");
                }
                else if ((Vzdegree1 > 75 || Vzdegree1 < 0)&& (Vzdegree2 > 0 || Vzdegree2 < 75)){
                    ui->textBrowser_4->append("Barrel max 75");
                    ui->textBrowser_4->append(QString::number(heightprojectory2));
                }
                else {
                    ui->textBrowser_4->append(QString::number(heightprojectory1));
                    ui->textBrowser_4->append(QString::number(heightprojectory2));
                }

                ui->textBrowser_5->setText("The target at:");
                if (xcoordinate > 0 && ycoordinate > 0 || xcoordinate > 0){
                    ui->textBrowser_5->append(QString::number(valuedegree));
                }
                else if (xcoordinate < 0 && ycoordinate > 0 || xcoordinate < 0){
                    valuedegree = 180 - valuedegree;
                    ui->textBrowser_5->append(QString::number(valuedegree));
                }
                else if (xcoordinate < 0 && ycoordinate < 0){
                    valuedegree = 180 - valuedegree;
                    ui->textBrowser_5->append(QString::number(valuedegree));
                }
                else {
                    valuedegree = 360 - valuedegree;
                    ui->textBrowser_5->append(QString::number(valuedegree));
                }

                ui->textBrowser_6->setText("2 Hit prediciton:");
                if ((Vzdegree2 > 75 || Vzdegree2 < 0) && (Vzdegree1 > 0 || Vzdegree1 < 75)) {
                    ui->textBrowser_6->append(QString::number(radius2));
                    ui->textBrowser_6->append("Barrel max 75");
                }
                else if ((Vzdegree1 > 75 || Vzdegree1 < 0)&& (Vzdegree2 > 0 || Vzdegree2 < 75)){
                    ui->textBrowser_6->append("Barrel max 75");
                    ui->textBrowser_6->append(QString::number(radius3));
                }
                else {
                    ui->textBrowser_6->append(QString::number(radius2));
                    ui->textBrowser_6->append(QString::number(radius3));
                }
            } //the second condition use the same formula as the first one
            else if (zcoordinate < 0 || zcoordinate > 0) {
                double AQ = gravitational*radius*radius/(2*shell_105mm_velociy*shell_105mm_velociy);
                double BQ = -radius;
                double CQ = zcoordinate + A;
                double DiscriminantQ = BQ*BQ - 4*AQ*CQ;
                if (DiscriminantQ < 0){
                    ui->textBrowser->append("Target is out of reach");
                    ui->textBrowser_2->append("Target is out of reach");
                    ui->textBrowser_3->append("Target is out of reach");
                    ui->textBrowser_4->append("Target is out of reach");
                    ui->textBrowser_5->append("Target is out of reach");
                    ui->textBrowser_6->append("Target is out of reach");
                }
                else {
                    double v = qSqrt(DiscriminantQ);

                    double A1 = (-BQ + v);
                    double A2 = (-BQ - v);

                    double C1 = 2*A;

                    double A11 = A1/C1;
                    double A22 = A2/C1;

                    double A111 = qAtan(A11);
                    double A222 = qAtan(A22);

                    double angleA = qRadiansToDegrees(A111);
                    double angleB = qRadiansToDegrees(A222);

                    AngleA = angleA;
                    AngleB = angleB;

                    double n1 = -zcoordinate;

                    Degreesin1 = qSin(qDegreesToRadians(angleA));
                    Degreesin2 = qSin(qDegreesToRadians(angleB));

                    Degreecos1 = qCos(qDegreesToRadians(angleA));
                    Degreecos2 = qCos(qDegreesToRadians(angleB));

                    double Vx1 = shell_105mm_velociy*Degreecos1;
                    double Vx2 = shell_105mm_velociy*Degreecos2;

                    double Vz1 = shell_105mm_velociy*Degreesin1;
                    double Vz2 = shell_105mm_velociy*Degreesin2;

                    double heightA = n1 + (Vz1*Vz1/(2*gravitational));
                    double heightB = n1 + (Vz2*Vz2/(2*gravitational));

                    double sq1 = qSqrt(Vz1*Vz1 + 2*gravitational*n1);
                    double sq2 = qSqrt(Vz2*Vz2 + 2*gravitational*n1);

                    double CT1 = (Vz1 + sq1);
                    double CT2 = (Vz2 + sq2);

                    double timeA = CT1/gravitational;
                    double timeB = CT2/gravitational;

                    double hitprediction1 = Vx1*timeA;
                    double hitprediction2 = Vx2*timeB;

                    double degreez = qRadiansToDegrees(qAtan(zcoordinate/radius));

                    refrence1 = hitprediction1;
                    refrence2 = hitprediction2;

                    if((angleA > 75 || angleA < 0)&&(angleB< 0 || angleB > 75)){
                        ui->textBrowser->append("You've reached the more than max angle");
                        ui->textBrowser_2->append("You've reached the more than max angle");
                        ui->textBrowser_3->append("You've reached the more than max angle");
                        ui->textBrowser_4->append("You've reached the more than max angle");
                        ui->textBrowser_5->append("You've reached the more than max angle");
                        ui->textBrowser_6->append("You've reached the more than max angle");
                    }
                    else if (accuracyA > 100 || accuracyB > 100){
                        ui->textBrowser->append("Target is out of reach");
                        ui->textBrowser_2->append("Target is out of reach");
                        ui->textBrowser_3->append("Target is out of reach");
                        ui->textBrowser_4->append("Target is out of reach");
                        ui->textBrowser_5->append("Target is out of reach");
                        ui->textBrowser_6->append("Target is out of reach");
                    }
                    else {
                        ui->textBrowser_2->setText("2 time prediciton:");
                        if ((angleB > 75 || angleB < 0) && (angleA > 0 || angleA < 75)){
                            ui->textBrowser_2->append(QString::number(timeA));
                            ui->textBrowser_2->append("Barrel max 75");

                        }
                        else if ((angleA > 75 || angleA < 0) && (angleB > 0 || angleB < 75)){
                            ui->textBrowser_2->append("Barrel max 75");
                            ui->textBrowser_2->append(QString::number(timeB));
                        }
                        else {
                            ui->textBrowser_2->append(QString::number(timeA));
                            ui->textBrowser_2->append(QString::number(timeB));
                        }
                        ui->textBrowser->setText(" 2 Degree recommended (Max 75):");
                        if ((angleB > 75 || angleB < 0) && (angleA > 0 || angleA < 75)){

                            ui->textBrowser->append(QString::number(angleA));
                            ui->textBrowser->append("Barrel max 75");
                        }
                        else if ((angleA > 75 || angleA < 0) && (angleB > 0 || angleB < 75)){
                            ui->textBrowser->append("Barrel max 75");
                            ui->textBrowser->append(QString::number(angleB));
                        }
                        else {
                            ui->textBrowser->append(QString::number(angleA));
                            ui->textBrowser->append(QString::number(angleB));

                        }

                        ui->textBrowser_3->setText("Distance between target and howitzer:");
                        ui->textBrowser_3->append(QString::number(radius));

                        ui->textBrowser_4->setText("2 Maximum height of projectile:");
                        if((angleB > 75 || angleB < 0) && (angleA > 0 || angleA < 75)){
                            ui->textBrowser_4->append(QString::number(heightA));
                            ui->textBrowser_4->append("Barrel max 75");
                        }
                        else if ((angleA > 75 || angleA < 0) && (angleB > 0 || angleB < 75)){
                            ui->textBrowser_4->append("Barrel max 75");
                            ui->textBrowser_4->append(QString::number(heightB));
                        }
                        else {
                            ui->textBrowser_4->append(QString::number(heightA));
                            ui->textBrowser_4->append(QString::number(heightB));
                        }
                        ui->textBrowser_5->setText("The target at:");
                        ui->textBrowser_5->append(QString::number(valuedegree));
                        ui->textBrowser_5->append(QString::number(degreez));


                        ui->textBrowser_6->setText("2 Hit prediciton");
                        if ((angleB > 75 || angleB < 0) && (angleA > 0 || angleA < 75)) {
                            ui->textBrowser_6->append(QString::number(hitprediction1));
                            ui->textBrowser_6->append("Barrel max 75");
                        }
                        else if ((angleA > 75 || angleA < 0) && (angleB > 0 || angleB < 75)){
                            ui->textBrowser_6->append("Barrel max 75");
                            ui->textBrowser_6->append(QString::number(hitprediction2));
                        }
                        else {
                            ui->textBrowser_6->append(QString::number(hitprediction1));
                            ui->textBrowser_6->append(QString::number(hitprediction2));
                        }
                    }
                }
            }




    }
        }
    } }

void MainWindow::accuracy1(){ //comparing between hit prediction and target distance
    double a = ((radius2 + radius3)/(radius + radius))*100;
    double b = ((refrence1 + refrence2)/(radius + radius))*100;
    accuracyA = a;
    accuracyB = b;

    ui->textBrowser_8->setText("Accuracy data:");
    if (zcoordinate == 0){
        if (Vzdegree1 > 75 && Vzdegree2 < 0){
            ui->textBrowser_8->append("You've reached more than max angle");
        }
        else {
            ui->textBrowser_8->append(QString::number(accuracyA));
        }
    }
    else if (zcoordinate > 0 || zcoordinate < 0){
        if (AngleA > 75 && AngleB < 0){
            ui->textBrowser_8->append("You've reached more than max angle");
        }
        else {
            ui->textBrowser_8->append(QString::number(accuracyB));
        }
    }


}

void MainWindow::chartcalculation(){
    QLineSeries *series = new QLineSeries(); //create series of plot diagram
    series = new QLineSeries();
        for (int i = 1; i <= 75; i++){
//recalculate any possibility angle
            double CDegreesin = qSin(qDegreesToRadians((double) i));
            double CDegreecos = qCos(qDegreesToRadians((double) i));

            double Vy = shell_105mm_velociy*CDegreesin;
            double Vx = shell_105mm_velociy*CDegreecos;

            Time = 2*Vy/gravitational;
            targetprediction = Vx*Time;
            series->append(i, targetprediction);

            } //set chart decoration
        QChart *chart = new QChart();
        chart->addSeries(series);
        chart->setTitle("Projectile Distance by Angle");
        chart->legend()->hide();

        QValueAxis *axisX = new QValueAxis();
        axisX->setRange(1, 75);
        axisX->setTitleText("Angle (Degrees)");
        axisX->setLabelFormat("%d");

        QValueAxis *axisY = new QValueAxis();
        axisY->setTitleText("Distance (m)");


        chart->addAxis(axisX, Qt::AlignBottom);
        chart->addAxis(axisY, Qt::AlignLeft);

        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);

        QVBoxLayout *layout = new QVBoxLayout(ui->widget);
        layout->addWidget(chartView);
}

void MainWindow::on_pushButton_pressed()
{ // reconstruct the structure
    getInput();
    calculation1();
    accuracy1();

}

void MainWindow::on_pushButton_2_pressed()
{ //triggering the button
    chartcalculation();
}

// void MainWindow::calculation() {
//     if (xcoordinate == 0 && ycoordinate == 0 ){
//         ui->textBrowser->append("Please put x or y value to define your target");
//         ui->textBrowser_2->append("Please put x or y value to define your target");
//         ui->textBrowser_3->append("Please put x or y value to define your target");
//     }
//     else {
//         radius = qSqrt(pow(xcoordinate, 2) + pow(ycoordinate, 2));
//         double a = qAsin(ycoordinate/radius);
//         double valuedegree = qRadiansToDegrees(a);

//         Vzdegree = qAsin(gravitational*radius/pow(shell_105mm_velociy, 2)/2);
//         Vzdegree1 = qRadiansToDegrees(Vzdegree);
//         Vzdegree2 = 90 - Vzdegree1;

//         p = qSin(qDegreesToRadians(Vzdegree1));
//         x = qCos(qDegreesToRadians(Vzdegree1));

//         j = qCos(qDegreesToRadians(Vzdegree2));
//         h = qSin(qDegreesToRadians(Vzdegree2));

//         if (Vzdegree1 > 75){
//             ui->textBrowser->append("You've reached more than max angle");
//             ui->textBrowser_2->append("You've reached more than max angle");
//             ui->textBrowser_3->append("You've reached more than max angle");
//             ui->textBrowser_4->append("You've reached more than max angle");
//             ui->textBrowser_5->append("You've reached more than max angle");
//             ui->textBrowser_6->append("You've reached more than max angle");
//         }

//         else{
//             if (zcoordinate == 0) {
//         double Vz = p*shell_105mm_velociy;
//         double Vxy1 = x*shell_105mm_velociy;

//         double heightprojectory1 = pow(shell_105mm_velociy, 2)*pow(p,2)/(2*gravitational);
//         double heightprojectory2 = pow(shell_105mm_velociy, 2)*pow(h,2)/(2*gravitational);

//         // double time = shell_105mm_velociy*p/gravitational + qSqrt(2*heightprojectory1/gravitational);
//         // double time2 = shell_105mm_velociy*h/gravitational + qSqrt(2*heightprojectory2/gravitational);

//         predictiontime1 = 2*shell_105mm_velociy*p/gravitational;
//         predictiontime2 = 2*shell_105mm_velociy*h/gravitational;

//         radius2 = Vxy1*predictiontime1;
//         radius3 = j*shell_105mm_velociy*predictiontime2;




//         ui->textBrowser_2->setText("2 time prediciton:");
//         if (Vzdegree2 > 75){
//             ui->textBrowser_2->append(QString::number(predictiontime1));
//             ui->textBrowser_2->append("Barrel max 75");
//         }
//         else{
//                 ui->textBrowser_2->append(QString::number(predictiontime1));
//                 ui->textBrowser_2->append(QString::number(predictiontime2));
//         }

//         ui->textBrowser->setText(" 2 recommended degree (Max 75):");
//         if (Vzdegree2 > 75){
//                 ui->textBrowser->append(QString::number(Vzdegree1));
//                 ui->textBrowser->append("Barrel max 75");

//         }
//         else {
//                 ui->textBrowser->append(QString::number(Vzdegree1));
//                 ui->textBrowser->append(QString::number(Vzdegree2));

//         }

//         ui->textBrowser_3->setText("Distance between target and howitzer:");
//         ui->textBrowser_3->append(QString::number(radius));

//         ui->textBrowser_4->setText("2 Maximum height of projectile:");
//         if(Vzdegree2 > 75){
//                 ui->textBrowser_4->append(QString::number(heightprojectory1));
//                 ui->textBrowser_4->append("Barrel max 75");
//         }
//         else {
//             ui->textBrowser_4->append(QString::number(heightprojectory1));
//             ui->textBrowser_4->append(QString::number(heightprojectory2));
//         }

//         ui->textBrowser_5->setText("The target at:");
//         if (xcoordinate > 0 && ycoordinate > 0 || xcoordinate > 0){
//             ui->textBrowser_5->append(QString::number(valuedegree));
//         }
//         else if (xcoordinate < 0 && ycoordinate > 0 || xcoordinate < 0){
//             valuedegree = 180 - valuedegree;
//             ui->textBrowser_5->append(QString::number(valuedegree));
//         }
//         else if (xcoordinate < 0 && ycoordinate < 0){
//             valuedegree = 180 - valuedegree;
//             ui->textBrowser_5->append(QString::number(valuedegree));
//         }
//         else {
//             valuedegree = 360 - valuedegree;
//             ui->textBrowser_5->append(QString::number(valuedegree));
//         }


//         ui->textBrowser_6->setText("2 Hit prediciton:");
//         if (Vzdegree2 > 75) {
//             ui->textBrowser_6->append(QString::number(radius2));
//             ui->textBrowser_6->append("Barrel max 75");
//         }
//         else {
//             ui->textBrowser_6->append(QString::number(radius2));
//             ui->textBrowser_6->append(QString::number(radius3));
//         }
//             }
//             else if (zcoordinate < 0 || zcoordinate > 0) {
//                 double A = gravitational*radius*radius/(2*shell_105mm_velociy*shell_105mm_velociy);
//                 double B = -radius;
//                 double C = zcoordinate + A;
//                 double Discriminant = B*B - 4*A*C;
//                 if (Discriminant < 0){
//                     ui->textBrowser->append("Target is out of reach");
//                     ui->textBrowser_2->append("Target is out of reach");
//                     ui->textBrowser_3->append("Target is out of reach");
//                     ui->textBrowser_4->append("Target is out of reach");
//                     ui->textBrowser_5->append("Target is out of reach");
//                     ui->textBrowser_6->append("Target is out of reach");
//                 }
//                 else {
//                 double v = qSqrt(Discriminant);

//                 double A1 = (-B + v);
//                 double A2 = (-B - v);

//                 double C1 = 2*A;

//                 double A11 = A1/C1;
//                 double A22 = A2/C1;

//                 double A111 = qAtan(A11);
//                 double A222 = qAtan(A22);

//                 double angleA = qRadiansToDegrees(A111);
//                 double angleB = qRadiansToDegrees(A222);

//                 double n1 = -zcoordinate;

//                 double Degreesin1 = qSin(qDegreesToRadians(angleA));
//                 double Degreesin2 = qSin(qDegreesToRadians(angleB));

//                 double Degreecos1 = qCos(qDegreesToRadians(angleA));
//                 double Degreecos2 = qCos(qDegreesToRadians(angleB));

//                 double Vx1 = shell_105mm_velociy*Degreecos1;
//                 double Vx2 = shell_105mm_velociy*Degreecos2;

//                 double Vz1 = shell_105mm_velociy*Degreesin1;
//                 double Vz2 = shell_105mm_velociy*Degreesin2;

//                 double heightA = n1 + (Vz1*Vz1/(2*gravitational));
//                 double heightB = n1 + (Vz2*Vz2/(2*gravitational));

//                 double sq1 = qSqrt(Vz1*Vz1 + 2*gravitational*n1);
//                 double sq2 = qSqrt(Vz2*Vz2 + 2*gravitational*n1);

//                 double CT1 = (Vz1 + sq1);
//                 double CT2 = (Vz2 + sq2);

//                 double timeA = CT1/gravitational;
//                 double timeB = CT2/gravitational;

//                 double hitprediction1 = Vx1*timeA;
//                 double hitprediction2 = Vx2*timeB;

//                 double degreez = qTan(qRadiansToDegrees(zcoordinate/radius));

//                 if(angleA > 75 && angleB < 0){
//                     ui->textBrowser->append("You've reached the more than max angle");
//                     ui->textBrowser_2->append("You've reached the more than max angle");
//                     ui->textBrowser_3->append("You've reached the more than max angle");
//                     ui->textBrowser_4->append("You've reached the more than max angle");
//                     ui->textBrowser_5->append("You've reached the more than max angle");
//                     ui->textBrowser_6->append("You've reached the more than max angle");
//                 }
//                 else {
//                     ui->textBrowser_2->setText("2 time prediciton:");
//                     if (angleB > 75){
//                         ui->textBrowser_2->append(QString::number(timeA));
//                         ui->textBrowser_2->append("Barrel max 75");

//                     }
//                     else if (angleA > 75){
//                         ui->textBrowser_2->append("Barrel max 75");
//                         ui->textBrowser_2->append(QString::number(timeB));
//                     }
//                     else {
//                         ui->textBrowser_2->append(QString::number(timeA));
//                         ui->textBrowser_2->append(QString::number(timeB));
//                     }
//                     ui->textBrowser->setText(" 2 Degree recommended (Max 75):");
//                     if (angleB > 75){

//                         ui->textBrowser->append(QString::number(angleA));
//                         ui->textBrowser->append("Barrel max 75");
//                     }
//                     else if (angleA > 75){
//                         ui->textBrowser->append("Barrel max 75");
//                         ui->textBrowser->append(QString::number(angleB));
//                     }
//                     else {
//                         ui->textBrowser->append(QString::number(angleA));
//                         ui->textBrowser->append(QString::number(angleB));

//                     }

//                     ui->textBrowser_3->setText("Distance between target and howitzer:");
//                     ui->textBrowser_3->append(QString::number(radius));

//                     ui->textBrowser_4->setText("2 Maximum height of projectile:");
//                     if(angleB > 75){
//                         ui->textBrowser_4->append(QString::number(heightA));
//                         ui->textBrowser_4->append("Barrel max 75");
//                     }
//                     else if (angleA > 75){
//                         ui->textBrowser_4->append("Barrel max 75");
//                         ui->textBrowser_4->append(QString::number(heightB));
//                     }
//                     else {
//                         ui->textBrowser_4->append(QString::number(heightA));
//                         ui->textBrowser_4->append(QString::number(heightB));
//                     }
//                     ui->textBrowser_5->setText("The target at:");
//                     ui->textBrowser_5->append(QString::number(valuedegree));
//                     ui->textBrowser_5->append(QString::number(degreez));


//                     ui->textBrowser_6->setText("2 Hit prediciton");
//                     if (angleB > 75) {
//                         ui->textBrowser_6->append(QString::number(hitprediction1));
//                         ui->textBrowser_6->append("Barrel max 75");
//                     }
//                     else if (angleA > 75){
//                         ui->textBrowser_6->append("Barrel max 75");
//                         ui->textBrowser_6->append(QString::number(hitprediction2));
//                     }
//                     else {
//                         ui->textBrowser_6->append(QString::number(hitprediction1));
//                         ui->textBrowser_6->append(QString::number(hitprediction2));
//                     }
//                     }
//                 }
//                     }
//                 }

//                 }
//             }







// void MainWindow::calibrate(){

//     if (xcoordinate == 0 && ycoordinate == 0 ){
//         ui->Calibration1->append("Please put x or y value to define your target");
//         ui->Calibration1_2->append("Please put x or y value to define your target");
//         ui->Calibration1_4->append("Please put x or y value to define your target");
//         ui->Calibration1_6->append("Please put x or y value to define your target");
//     }
//     else {
//     radius = qSqrt(pow(xcoordinate, 2) + pow(ycoordinate, 2));

//     Vzdegree = gravitational*radius/pow(shell_105mm_velociy, 2)/2;
//     Vzdegree1 = qRadiansToDegrees(Vzdegree);
//     Vzdegree2 = 90 - Vzdegree1;

//     p = qSin(qDegreesToRadians(Vzdegree1));
//     x = qCos(qDegreesToRadians(Vzdegree1));

//     j = qCos(qDegreesToRadians(Vzdegree2));
//     h = qSin(qDegreesToRadians(Vzdegree2));

//     double calibrationdegree1 = Vzdegree1*radius/radius2;
//     double calibrationdegree2 = 90 - calibrationdegree1;



//     double pA1 = qSin(qDegreesToRadians(calibrationdegree1));
//     double pA2 = qSin(qDegreesToRadians(calibrationdegree2));

//     double gA1 = qCos(qDegreesToRadians(calibrationdegree1));
//     double gA2 = qCos(qDegreesToRadians(calibrationdegree2));

//     if (calibrationdegree1 > 90 && calibrationdegree2 < 0){
//         double sindegreeA1 = qRadiansToDegrees(pA1);
//         double sindegreeA2 = qRadiansToDegrees(pA2);
//         caldegreesin1 = 180 - qRadiansToDegrees(sindegreeA1);
//         caldegreesin2 = 180 - qRadiansToDegrees(sindegreeA2);

//         p1 = qSin(qDegreesToRadians(caldegreesin1));
//         p2 = qSin(qDegreesToRadians(caldegreesin2));

//     }
//     else{
//         p1 = pA1;
//         p2 = pA2;

//         g1 = gA1;
//         g2 = gA2;
//     }

//     double timeA1 = 2*shell_105mm_velociy*p1/gravitational;
//     double timeA2 = 2*shell_105mm_velociy*p2/gravitational;

//     double Hit1 = g1*shell_105mm_velociy*timeA1;
//     double Hit2 = g2*shell_105mm_velociy*timeA2;

//     double heightcal1 = pow(shell_105mm_velociy, 2)*pow(p1,2)/(2*gravitational);;
//     double heightcal2 = pow(shell_105mm_velociy, 2)*pow(p2,2)/(2*gravitational);;

//     refrence2 = Hit1;
//     refrence1 = calibrationdegree1;

//     if (calibrationdegree1 > 75) {
//         ui->Calibration1->append("You've reached more than max angle");
//         ui->Calibration1_2->append("You've reached more than max angle");
//         ui->Calibration1_4->append("You've reached more than max angle");
//         ui->Calibration1_6->append("You've reached more than max angle");

//     }
//     else {


//     ui->Calibration1->setText("2 recommended degree (Max 75):");
//     if (calibrationdegree2 > 75){
//         ui->Calibration1->append(QString::number(calibrationdegree1));
//         ui->Calibration1->append("Barrel max 75");

//     }
//     else {
//        ui->Calibration1->append(QString::number(calibrationdegree1));
//        ui->Calibration1->append(QString::number(calibrationdegree2));

//     }

//     ui->Calibration1_2->setText("2 time prediction:");
//     if (calibrationdegree2 > 75){
//         if (calibrationdegree1 )
//         ui->Calibration1_2->append(QString::number(timeA1));
//         ui->Calibration1_2->append("Barrel max 75");

//     }
//     else {
//         ui->Calibration1_2->append(QString::number(timeA1));
//         ui->Calibration1_2->append(QString::number(timeA2));

//     }

//     ui->Calibration1_6->setText("2 Hit prediciton:");
//     if (calibrationdegree2 > 75){
//         ui->Calibration1_6->append(QString::number(Hit1));
//         ui->Calibration1_6->append("Barrel max 75");

//     }
//     else {
//         ui->Calibration1_6->append(QString::number(Hit1));
//         ui->Calibration1_6->append(QString::number(Hit2));

//     }

//     ui->Calibration1_4->setText("2 Maximum height of projectile:");
//     if (calibrationdegree2 > 75){
//         ui->Calibration1_4->append(QString::number(heightcal1));
//         ui->Calibration1_4->append("Barrel max 75");

//     }
//     else {
//         ui->Calibration1_4->append(QString::number(heightcal1));
//         ui->Calibration1_4->append(QString::number(heightcal2));

//     }
//     }
//     }
// }
// void MainWindow::accuracy2(){
//     double b = refrence2/radius*100;
//     ui->textBrowser_7->setText("Accuracy from calibrated data:");
//     if (refrence1 > 75){
//         ui->textBrowser_7->append("You've reached more than max angle");
//     }
//     else {

//     ui->textBrowser_7->append(QString::number(b));
//     }
// }

// void MainWindow::on_pushButton_2_pressed()
// {
//     getInput();
//     calibrate();
//     accuracy2();
// }
